package fil;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Options extends JFrame implements ActionListener {
	int nbRow;			// Nombre de lignes
	int nbCol;			// Nombre de colonnes
	boolean computerOn = false;	// Ordinateur activé ou non
	boolean computerStarts = false;
	Jeu jeu;
	
	GridBagLayout gbl = new GridBagLayout();
	GridBagConstraints constraints = new GridBagConstraints();
	JPanel pane = new JPanel();
	
	JPanel lignesColPane = new JPanel();
	JLabel label1 = new JLabel("Nombre de lignes du tableau :");
	JTextField text1 = new JTextField("6", 2);
	JLabel label2 = new JLabel("Nombre de colonnes du tableau :");
	JTextField text2 = new JTextField("7", 2);
	
	JCheckBox checkBox1 = new JCheckBox("Jouer contre l'ordinateur", false);
	JLabel label3 = new JLabel("L'ordinateur commence");
	ButtonGroup ouiNon = new ButtonGroup();
	JRadioButton oui = new JRadioButton("Oui", false);
	JRadioButton non = new JRadioButton("Non", true);
	//JLabel label4 = new JLabel("Difficulté");
	JSlider slider1 = new JSlider(1, 9, 1);
	
	JPanel ouiNonPane = new JPanel();

	JButton ok = new JButton("Ok");
	
	public void buildConstraints (GridBagConstraints gbc, int gx, int gy, int gw, int gh, int wx, int wy) {
		gbc.gridx = gx;			// Coordonnées dans la "grille"
		gbc.gridy = gy;
		gbc.gridwidth = gw;		// Nombre de cellules sur lesquelles s'étend l'objet
		gbc.gridheight = gh; 
		gbc.weightx = wx;		// "Largeur", en proportion
		gbc.weighty = wy;
	}
	
	public Options(Jeu j) {
		super("Options de jeu");
		setSize(600, 400);
		setLocation(50, 50);

		this.jeu = j;
		
		pane.setLayout(gbl);
		
		// Nb de lignes, colonnes
		buildConstraints(constraints, 0, 0, 2, 1, 80, 30);
		lignesColPane.setLayout(new GridLayout(2, 2, 10, 10));
		lignesColPane.add(label1);
		lignesColPane.add(text1);
		lignesColPane.add(label2);
		lignesColPane.add(text2);
		gbl.setConstraints(lignesColPane, constraints);
		
		pane.add(lignesColPane);
		
		
		// L'ordinateur joue ?
		buildConstraints(constraints, 0, 1, 2, 1, 0, 10);
		gbl.setConstraints(checkBox1, constraints);
		pane.add(checkBox1);
		
		// L'ordinateur commence ?
		buildConstraints(constraints, 0, 3, 1, 1, 0, 10);
		gbl.setConstraints(label3, constraints);
		pane.add(label3);
		buildConstraints(constraints, 1, 3, 1, 1, 0, 0);
		gbl.setConstraints(ouiNonPane, constraints);
		ouiNonPane.setLayout(new BorderLayout());
		ouiNon.add(non);  // On ajoute au groupe
		ouiNon.add(oui);
		ouiNonPane.add(non, "North");    // On ajoute au panel
		ouiNonPane.add(oui, "South");
		pane.add(ouiNonPane);
		
		buildConstraints(constraints, 0, 4, 1, 1, 0, 10);
		//gbl.setConstraints(label4, constraints);
		//pane.add(label4);
		
		buildConstraints(constraints, 1, 4, 1, 1, 0, 10);
		// On donne des attributs au slider1
		slider1.setMajorTickSpacing(4);
		slider1.setMinorTickSpacing(1);
		slider1.setPaintTicks(true);
		slider1.setPaintLabels(true);
		slider1.setSnapToTicks(true);
		gbl.setConstraints(slider1, constraints);
		pane.add(slider1);
		
		// Bouton Ok
		ok.addActionListener(this);
		
		buildConstraints(constraints, 1, 6, 2, 1, 0, 20);
		gbl.setConstraints(ok, constraints);
		pane.add(ok);
		
		setContentPane(pane);
		setVisible(true);
	}
	
	public Options(int nbR, int nbC, Jeu jeu) {
		this.nbRow = nbR;
		this.nbCol = nbC;
		this.jeu = jeu;
		jeu.plateau = new Grille(nbRow, nbCol, jeu);
		jeu.plateau.setVisible(true);
		jeu.matJeu = new byte[nbRow][nbCol];
		jeu.historique = new int[nbRow * nbCol];
	}
	
	public void actionPerformed(ActionEvent evt) {
		Object src = evt.getSource();
		
		if (src == ok) {
			try {
				nbRow = Integer.parseInt(text1.getText());
				nbCol = Integer.parseInt(text2.getText());
				if (nbRow <= 0 || nbCol <= 0)
					nbRow = Integer.parseInt("h");
				setVisible(false);
				
				jeu.plateau = new Grille(nbRow, nbCol, jeu);
				jeu.plateau.setVisible(true);
				jeu.matJeu = new byte[nbRow][nbCol];
				jeu.historique = new int[nbRow * nbCol];
				jeu.deep = new Computer(slider1.getValue()); // on crée tout le temps l'ordinateur, si l'utilisateur clique sur Jouer...
				if (checkBox1.isSelected()) {
					computerOn = true;
				}
				if (oui.isSelected())
					computerStarts = true;
				
			} catch (NumberFormatException e) {
				Saisie.erreurMsgOk("Erreur : le nombre de ligne et le nombre de colonnes doivent être des entiers", "Erreur");
			}
			if (computerStarts)
				jeu.ordiJoue();
		}
	}	
}
